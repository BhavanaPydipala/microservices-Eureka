package com.example.demo;


import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CreateEmployeeApplicationTests {

	@Test
	void contextLoads() {
	}

}
