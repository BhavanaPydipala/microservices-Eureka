package com.cap.anurag;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CreateEmployeeApplication {

	public static void main(String[] args) {
		SpringApplication.run(CreateEmployeeApplication.class, args);
	}

}
